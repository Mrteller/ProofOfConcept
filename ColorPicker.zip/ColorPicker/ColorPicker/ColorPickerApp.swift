//
//  ColorPickerApp.swift
//  ColorPicker
//
//  Created by Paul on 19.05.2022.
//

import SwiftUI

@main
struct ColorPickerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
